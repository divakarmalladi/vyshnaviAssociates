<?php $sess = session();?>
<main id="main">
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Clients</h2>
          <ol>
            <li><a href="<?php echo base_url();?>/user-dashboard">Dashboard</a></li>
            <li>Clients</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page contact">
        <div class="container">
            <div class="row">
                <!-- <div class="col-xl-12 col-md-12" style="text-align:right;">
                    <a href="<?php echo base_url();?>/clients" type="button" class="btn btn-outline-primary">Add User</a>
                </div> -->
                <div class="col-xl-12 col-md-12">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Customer Name</th>
                                <th scope="col">Customer ID</th>
                                <th scope="col">Aadhar</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Project</th>
                                <?php if ($sess->userData['user_type'] != 3) { ?>
                                <th scope="col">Alloted To</th>
                                <?php } ?>
                                <th scope="col">Action</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($clients)) { 
                                foreach($clients as $key => $value) {
                            ?>
                            <tr>
                                <th scope="row"><?php echo $key + 1;?></th>
                                <td><?php echo $value['customer_name'];?></td>
                                <td><?php echo $value['customer_id'];?></td>
                                <td><?php echo $value['aadhar_number'];?></td>
                                <td><?php echo $value['contact_number'];?></td>
                                <td><?php echo $value['type_of_project'];?></td>
                                <?php if ($sess->userData['user_type'] != 3) { ?>
                                <td><?php echo $value['alloted_id'];?></td>
                                <?php } ?>
                                <td>
                                  <?php if ($sess->userData['user_type'] == 1) { ?>
                                  <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModalemp" onClick="return setUserId('<?php echo $value['customer_id']?>', '<?php echo $value['alloted_id'];?>');"> Allot </button>
                                  <?php } ?>
                                  <a style="border-radius:0px;" href="<?php echo base_url('edit-client/'.$value['customer_id']);?>" class="btn btn-primary btn-sm"> Edit </a> 
                                  <?php if ($sess->userData['user_type'] != 3) { ?>
                                  <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal" onClick="return setCustomerId('<?php echo $value['customer_id']?>');"> Delete </button>
                                  <?php } ?>
                                </td>
                            </tr>
                            <?php } } else {  ?>
                            <tr>
                              <td colspan="8"><h1 class="text-center">No Clients Found</h1></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</main>


<!-- Modal -->
<div class="modal fade" id="exampleModalemp" tabindex="-1" aria-labelledby="exampleModalempLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalempLabel">Allot the client to Employee</h5>
        <input type="hidden" name="login_Id" id="login_Id" value="">
        <input type="hidden" name="customerId" id="customerId" value="">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form class="row g-3 php-email-form clientReg"  method="post">
          <div class="col-md-6 mb-3">
              <label for="employee_id" class="form-label">Select Employee</label>
              <select id="employee_id" name="employee_id" class="form-select" onChange="return updateEmployeeId(this.value)">
                  <option value="">Choose...</option>
                  <?php if (isset($users)) { 
                    foreach($users as $userKey => $userVal) {
                  ?>
                  <option value="<?php echo $userVal['login_id'];?>" ><?php echo  $userVal['user_name'].' - '.$userVal['login_id'];?></option>
                  <?php } } ?>
              </select>
          </div>
          <div class="my-2">
              <div class="loading" id="loading" style="display:none;">Loading</div>
              <div class="error-message" id="error-message"></div>
              <div class="sent-message" id="success-message"></div>
          </div>
        </form>
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Go Back</button>
        <button type="button" class="btn btn-success" onClick="return allotClient();">Allot</button>
      </div>
      
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are you sure?</h5>
        <input type="hidden" name="customer_id" id="customer_id" value="">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">No</button>
        <button type="button" class="btn btn-danger" onClick="return deleteClient();">Yes, Delete</button>
      </div>
      
    </div>
  </div>
</div>

<script>
const setCustomerId = (customer_id) => {
    document.getElementById('customer_id').value = customer_id;
}
const setUserId = (customer_id, user_id) => {
  $('#employee_id').val(user_id);
  document.getElementById('customerId').value = customer_id;
  document.getElementById('login_Id').value = user_id;
}
const updateEmployeeId = (val) => {
  document.getElementById('login_Id').value = val;
}
const deleteClient = () => {
    const customer_id = document.getElementById('customer_id').value;
    window.location.href = '<?php echo base_url('delete-client')?>/'+customer_id;
}
const allotClient = () => {
  const loginId = $('#login_Id').val();
  const customerId = $('#customerId').val();
  $('#loading').show();
  if (loginId != '') {
    const formData = {'loginId': loginId, 'customerId': customerId}
    $.ajax({
      url:"<?php echo base_url();?>/allot-client",
      method:"POST",
      data: JSON.stringify(formData),
      dataType: "json",
      contentType: "application/json; charset=utf-8",
    }).done(function( response ) {
      console.log(response);
      if (response.status == 200) {
        $('#success-message').html('Client allotted Successfully').css('color', 'green');
        $('#employee_id').val('');
        setTimeout(() => {
          window.location.href = '<?php echo base_url();?>/clients';
        }, 300);
      } 
      $('#loading').hide();
    }).fail(function( jqXHR, textStatus ) {
      $('#error-message').html('Something went wrong, Please try again').css('color', 'red');
      $('#loading').hide();
    });
  } else {
    $('#loading').hide();
    $('#error-message').html('Please select the employee').css('color', 'red');
  }
}
</script>